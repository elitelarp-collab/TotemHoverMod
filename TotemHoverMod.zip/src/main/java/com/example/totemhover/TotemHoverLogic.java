package com.example.totemhover;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Core logic for the "Totem Hover" feature.
 *
 * <h2>Design notes</h2>
 * <ul>
 *   <li><b>Which screens we act on:</b> We only act inside the player's own inventory screen
 *   ({@link InventoryScreen}, backed by {@link PlayerScreenHandler}). Container screens such as
 *   chests, barrels, and shulker boxes (rendered by {@code GenericContainerScreen}) use a
 *   {@code GenericContainerScreenHandler} which does <b>not</b> expose an offhand slot at all -
 *   there is nothing valid to swap into from there, so we explicitly ignore any screen whose
 *   handler isn't a {@link PlayerScreenHandler}.</li>
 *
 *   <li><b>How the swap is actually performed:</b> The task description suggests moving the item
 *   "into slot 45". While slot id 45 is indeed the offhand slot's persistent id inside
 *   {@link PlayerScreenHandler}, manually target-clicking slot 45 with {@code SlotActionType.PICKUP}
 *   twice (pickup totem, then click slot 45) is exactly the fragile, multi-step approach that
 *   causes duplication/desync bugs if a packet is dropped or the two clicks race with server-side
 *   state changes.
 *   <p>
 *   Instead, we replicate exactly what vanilla does when you hover an item and press the
 *   "Swap Item With Offhand" key (default F): a <b>single</b> packet -
 *   {@code clickSlot(syncId, hoveredSlot.id, 40, SlotActionType.SWAP, player)}. Button {@code 40}
 *   is a special sentinel value the server interprets as "swap this slot's contents with the
 *   offhand", independent of whatever the offhand's real slot id happens to be. This is a single
 *   atomic server-side operation, is exactly as safe as pressing F yourself, and is the correct
 *   "vanilla" way to do this rather than hand-rolling slot math.</li>
 *
 *   <li><b>Preventing packet spam / infinite loops:</b> We remember the last slot we evaluated
 *   and skip re-evaluating it on every subsequent render frame while the cursor sits still. This
 *   guarantees at most one swap attempt per hover "event", and it's naturally reset the moment the
 *   mouse moves to a different slot (or off all slots).</li>
 * </ul>
 */
public final class TotemHoverLogic {

    /** Special "button" value used by vanilla's swap-to-offhand action. Not a slot id. */
    private static final int OFFHAND_SWAP_BUTTON = 40;

    /** The persistent slot id of the offhand slot inside {@link PlayerScreenHandler}. */
    private static final int PLAYER_OFFHAND_SLOT_ID = 45;

    /** The last slot we evaluated; used purely to debounce repeated frames. */
    private static Slot lastEvaluatedSlot = null;

    private TotemHoverLogic() {
    }

    /**
     * Called once per render frame from {@code HandledScreenMixin}.
     *
     * @param screen      the currently open handled screen
     * @param hoveredSlot the slot currently focused/hovered by the mouse cursor, or {@code null}
     *                    if the cursor isn't over any slot
     */
    public static void tryHoverSwap(HandledScreen<?> screen, Slot hoveredSlot) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.player == null || client.interactionManager == null) {
            return;
        }

        // Edge case: wrong screen type entirely (not the player's own inventory).
        if (!(screen instanceof InventoryScreen)) {
            resetTracking();
            return;
        }

        // Edge case: handler doesn't have an offhand slot to swap into (defensive; InventoryScreen
        // should always pair with PlayerScreenHandler, but we don't assume that).
        if (!(screen.getScreenHandler() instanceof PlayerScreenHandler handler)) {
            resetTracking();
            return;
        }

        // Nothing hovered right now.
        if (hoveredSlot == null) {
            resetTracking();
            return;
        }

        // Debounce: don't re-process the same slot every single frame while the mouse is still.
        if (hoveredSlot == lastEvaluatedSlot) {
            return;
        }
        lastEvaluatedSlot = hoveredSlot;

        // Edge case: hovering the offhand slot itself - nothing to swap.
        if (hoveredSlot.id == PLAYER_OFFHAND_SLOT_ID) {
            return;
        }

        // Defensive: slot must have a backing inventory (should always be true here).
        if (hoveredSlot.inventory == null) {
            return;
        }

        ItemStack hoveredStack = hoveredSlot.getStack();
        if (hoveredStack.isEmpty() || !hoveredStack.isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }

        // Edge case: offhand already holds a totem - do nothing.
        ItemStack offhandStack = client.player.getOffHandStack();
        if (!offhandStack.isEmpty() && offhandStack.isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }

        // Perform the swap exactly the way vanilla's "swap with offhand" keybind does.
        client.interactionManager.clickSlot(
                handler.syncId,
                hoveredSlot.id,
                OFFHAND_SWAP_BUTTON,
                SlotActionType.SWAP,
                client.player
        );
    }

    private static void resetTracking() {
        lastEvaluatedSlot = null;
    }
}
