package com.example.totemhover;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-only entrypoint for the Totem Hover mod.
 *
 * All of the actual behavior lives in {@link TotemHoverLogic}, driven by the
 * {@code HandledScreenMixin}. This class exists mainly so Fabric Loader has
 * something to invoke on startup and so we have a place for shared constants
 * / a logger.
 */
public class TotemHoverClient implements ClientModInitializer {

    public static final String MOD_ID = "totem-hover";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Totem Hover] Initialized. Hover a Totem of Undying in your inventory " +
                "screen to automatically equip it to your offhand.");
    }
}
