package com.example.totemhover.mixin;

import com.example.totemhover.TotemHoverLogic;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into {@link HandledScreen} - the base class behind the survival inventory screen,
 * creative inventory, chests, and every other slot-based screen - to detect which slot the mouse
 * is hovering over each frame.
 *
 * <p>We inject at the {@code TAIL} of {@code render(...)} rather than at the head, because
 * {@code HandledScreen} recalculates its {@code focusedSlot} field <i>during</i> the render pass
 * (while it iterates and draws each slot). Reading the field at the tail guarantees we see this
 * frame's fully up-to-date value rather than last frame's stale one.
 *
 * <p><b>Mapping note:</b> under current Yarn mappings for 1.21.1, the hovered slot field on
 * {@code HandledScreen} is named {@code focusedSlot} (type {@code Slot}). If you're on a
 * different mapping set and this fails to compile, look for the protected {@code Slot} field that
 * {@code HandledScreen} updates every render call - some older mapping revisions called it
 * {@code hoveredSlot}.
 */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {

    @Shadow
    protected Slot focusedSlot;

    @Inject(
            method = "render(Lnet/minecraft/client/gui/DrawContext;IIF)V",
            at = @At("TAIL")
    )
    private void totemHover$onRenderTail(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        // Safe cast: this mixin body is only ever woven into HandledScreen (or a subclass of it),
        // so `this` is always assignable to HandledScreen<?>.
        HandledScreen<?> self = (HandledScreen<?>) (Object) this;
        TotemHoverLogic.tryHoverSwap(self, this.focusedSlot);
    }
}
